const dados = [
  {
    "id": "1",
    "nome": "Carros 1",
    "nota": 4.8,
    "img": "https://upload.wikimedia.org/wikipedia/pt/9/9b/Carros_p%C3%B4ster.jpg"
  },
  {
    "id": "2",
    "nome": "Carros 2",
    "nota": 4.6,
    "img": "https://th.bing.com/th/id/OSK.XL_QnhpWTN71PtHbKcLOICAl67IRkZSRAOYHBcg57rQ?w=80&h=118&c=7&o=6&dpr=1.3&pid=SANGAM"
  },
  {
    "id": "3",
    "nome": "Carros 3",
    "nota": 4.6,
    "img": "https://th.bing.com/th/id/OSK.UoFbwBNmcsMG0BwqlfvDY0-uim8Fpjl4OIuDQaUqWi8?w=80&h=118&c=7&o=6&dpr=1.3&pid=SANGAM"
  },
  {
    "id": "4",
    "nome": "Os Caras Malvados",
    "nota": 4.3,
    "img": "https://www.bing.com/th/id/OIP.dmebnnNnWib5xafZOLKLiAHaJQ?w=149&h=185&c=8&rs=1&qlt=90&o=6&dpr=1.3&pid=3.1&rm=2"
  },
  {
    "id": "5",
    "nome": "Os Caras Malvados 2",
    "nota": 4.4,
    "img": "https://th.bing.com/th/id/OIP.wgQm_hnNkMCoe73GOiih6AHaLv?w=115&h=182&c=7&r=0&o=5&dpr=1.3&pid=1.7"
  },
  {
    "id": "6",
    "nome": "Zootopia",
    "nota": 4.4,
    "img": "https://upload.wikimedia.org/wikipedia/pt/3/3b/ZootopiaOficialPoster.jpg"
  },
  {
    "id": "7",
    "nome": "Zootopia 2",
    "nota": 4.6,
    "img": "https://upload.wikimedia.org/wikipedia/pt/3/3a/Zootopia_2.jpg"
  },
  {
    "id": "8",
    "nome": "Robô Selvagem",
    "nota": 4.7,
    "img": "https://www.bing.com/th/id/OIP.OKDeP4OJSQXXJFpU85AkzwHaJQ?w=131&h=185&c=8&rs=1&qlt=90&o=6&dpr=1.3&pid=3.1&rm=2"
  },
  {
    "id": "9",
    "nome": "Kung Fu Panda 1",
    "nota": 4.5,
    "img": "https://upload.wikimedia.org/wikipedia/en/7/76/Kungfupanda.jpg"
  },
  {
    "id": "10",
    "nome": "Kung Fu Panda 2",
    "nota": 3.5,
    "img": "https://www.bing.com/th/id/OIP.2QdnF4yGnShSSmZG4DYYigHaKd?w=120&h=185&c=8&rs=1&qlt=90&o=6&dpr=1.3&pid=3.1&rm=2"
  },
  {
    "id": "11",
    "nome": "Kung Fu Panda 3",
    "nota": 3.2,
    "img": "https://www.bing.com/th/id/OIP.-xMevYbQUeZLj0Sx-a1VVQHaKE?w=120&h=185&c=8&rs=1&qlt=90&o=6&dpr=1.3&pid=3.1&rm=2"
  },
  {
    "id": "12",
    "nome": "Bolt",
    "nota": 3.7,
    "img": "https://www.bing.com/th/id/OIP.qpq_oxjeCOhSaHdM6hASPgHaHa?w=175&h=185&c=8&rs=1&qlt=90&o=6&dpr=1.3&pid=3.1&rm=2"
  },
  {
    "id": "13",
    "nome": "Rio",
    "nota": 3.3,
    "img": "https://th.bing.com/th/id/OIP.4LghItN4iCPKme2_9ntx0QHaLH?w=204&h=306&c=7&r=0&o=5&dpr=1.3&pid=1.7"
  },
  {
    "id": "14",
    "nome": "Rango",
    "nota": 4.4,
    "img": "https://th.bing.com/th/id/OIP.4BxVs1RPw2bRZgh3RRsDUAHaJ4?w=132&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7"
  },
  {
    "id": "15",
    "nome": "Gato de Botas 2",
    "nota": 4.8,
    "img": "https://th.bing.com/th/id/OIP.Sp_vS-Oyjd_v4zcMMyP3sQHaLH?w=115&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7"
  }
];

export default dados;
