
import {StyleSheet, View, Text, Image} from 'react-native'
import { useRoute } from '@react-navigation/native'


export default function Details(){

    const route = useRoute();

    return(
        <View style={stylest.body}>
             <Image style={stylest.images} source={{uri : route.params.img}}/>
            <Text style = {stylest.titulo}> {route.params.titulo} </Text>
            <Text style = {stylest.textoNota}> {route.params.nota} </Text>

             
        </View>
    )
}

const stylest = StyleSheet.create({
   
    titulo:{
        color: '#000000ff',
        fontSize:30,
    },

    textoNota:{
        fontSize:20,
        color:'#ffffffff',
        
    },

    images:{
        width:' 300',
        height:300,
        borderRadius:25,
        margin:50,
    },

    body:{
        backgroundColor:'red',
        flex:'1',
    }
    

})