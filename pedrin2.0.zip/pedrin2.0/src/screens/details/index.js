
import {View, Text, Image} from 'react-native'
import { useRoute } from '@react-navigation/native'
import stylest from '../details/style.js';

export default function Details(){

    const route = useRoute();

    return(
        <View>
             <Image style={stylest.images} source={{uri : route.params.img}}/>
            <Text> {route.params.titulo} </Text>
            <Text> {route.params.nota} </Text>
             
        </View>
    )
}

