
import Routes from "./src/routes/index.js";
import { Text } from "react-native-web";
export default function App() {
  return (
    <Routes></Routes>
  )
}